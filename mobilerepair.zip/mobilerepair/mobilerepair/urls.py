"""
URL configuration for mobilerepair project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from repair import views
from django.conf import settings
from django.conf.urls.static import static
from repair.views import home, MyPasswordResetView, MyPasswordResetDoneView, MyPasswordResetConfirmView, \
    MyPasswordResetCompleteView


urlpatterns = [
    # 🔧 Admin
    path('admin/', admin.site.urls),

    # 🔐 Authentication
    path('', views.login_view, name='login_register'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),

    # 🏠 Dashboard & Home
    path('home/', views.home, name='home'),
    path('technician_dashboard/', views.technician_dashboard, name='technician_dashboard'),

    # 📁 Firmware Management
    path('firmwares/', views.firmware_list, name='firmwares'),
    path('firmware/<int:firmware_id>/', views.firmware_info, name='firmware_info'),
    path('firmware/<slug:folder_slug>/', views.folder_detail_view, name='folder_detail'),

    # 🛠️ Repair Services
    path('add_repair/', views.Add_Repair_request, name='add_repair'),
    path('edit_repair/<int:repair_id>/', views.edit_repair, name='edit_repair'),
    path('delete_repair/<int:repair_id>/', views.delete_repair, name='delete_repair'),
    path('generate_invoice/', views.Add_Repair_request, name='generate_invoice'),  # Optional shortcut
    path('generate_invoice/<int:repair_id>/', views.generate_invoice, name='generate_invoice'),
    path('pdf_template/', views.delete_repair, name='pdf_template'),  # ⚠️ Confirm view logic

    # 👥 Customer & Staff
    path("add_customer_ac/", views.add_customer_account, name="add_customer_account"),
    path('add_technician/', views.add_technician, name='add_technician'),
    path('add_staff/', views.add_staff, name='add_staff'),

    # 📦 Phone Model / Device Details
    path('add_phone_model/', views.add_phone_model, name='add_phone_model'),
    path('get-device-models/', views.get_device_models, name='get_device_models'),
    path('delete-phone-model/<int:model_id>/', views.delete_phone_model, name='delete_phone_model'),

    # ⚙️ Profile & Account
    path('profile/', views.profile_view, name='profile'),
    path('profile/edit/', views.edit_profile, name='edit_profile'),

    # 📤 Export
    path('export-csv/', views.export_csv, name='export_csv'),
    path('export-pdf/', views.export_pdf, name='export_pdf'),

    # 🔐 Password Reset
    path("reset_password/", views.MyPasswordResetView.as_view(), name="password_reset"),
    path("reset_password_sent/", views.MyPasswordResetDoneView.as_view(), name="password_reset_done"),
    path("reset/<uidb64>/<token>/", views.MyPasswordResetConfirmView.as_view(), name="password_reset_confirm"),

    # 🔔 Subscriptions & Access
    path('subscribe/', views.subscribe_view, name='subscribe'),
    path('grant-access/', views.grant_access_view, name='grant_access'),

    # 📱 Samsung Tools
    path('samsung/tools/', views.samsung_tools, name='samsung_tools'),
    path('samsung/read-info/', views.samsung_read_info, name='samsung_read_info'),
    path('samsung-frp-support/', views.samsung_frp_support_list, name='samsung_frp_support_list'),

]

# ⚙️ Static/Media Files for Development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)




