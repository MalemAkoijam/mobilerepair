import csv
import json
import os

from django.contrib.admin.utils import unquote
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.db import IntegrityError
from django.http import  JsonResponse
from django.conf import settings
from django.contrib.auth import login, logout
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm

from django.http import HttpResponse, Http404
from django.template.loader import get_template
from django.urls import reverse_lazy
from django.views.decorators.csrf import csrf_exempt
from xhtml2pdf import pisa
from django.contrib.auth import views as auth_views
from .models import Customer, Technician, Firmware, FirmwareAccess, DeviceModel, FirmwareFolder, WindowsAppFile, \
    WindowsFirmware, ImageModel, CustomRegisterForm, SamsungModel
from django.shortcuts import render, get_object_or_404, redirect
from .models import FirmwareFolder, RepairRequest
from .forms import SubscriberForm, BulkSamsungUploadForm
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.db.models import Q
from django.contrib import messages

from django.contrib.auth.decorators import login_required

@login_required
def home(request):
    # ✅ Handle first-time login modal
    show_modal = False
    if request.session.get("show_modal"):
        show_modal = True
        del request.session["show_modal"]  # Only show once

    # Load firmware folders
    folders = FirmwareFolder.objects.all()

    # Search and pagination
    search_query = request.GET.get("search", "").strip()
    repairs_qs = RepairRequest.objects.select_related("customer", "technician")

    if search_query:
        repairs_qs = repairs_qs.filter(
            Q(customer__name__icontains=search_query) |
            Q(device_model__icontains=search_query) |
            Q(issue_description__icontains=search_query) |
            Q(status__icontains=search_query)
        )

    paginator = Paginator(repairs_qs, 13)
    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)

    # YouTube videos
    raw_videos = [
        "https://youtu.be/rVKSSqtrOvs?si=0u1CMU6dhWlKM6GI",
        "https://youtu.be/j1tca3qFCtw?si=19jMUQxuYDzTgrTB",
        "https://youtu.be/QFj92b_i86Q?si=vrL7-kwfVsqjG60v",
        "https://youtu.be/VQDJKifr4IE?si=z-Cu6M_XJEaRyo8H",
    ]
    def to_embed(url):
        if "youtu.be/" in url:
            return f"https://www.youtube.com/embed/{url.split('youtu.be/')[1].split('?')[0]}"
        elif "watch?v=" in url:
            return f"https://www.youtube.com/embed/{url.split('watch?v=')[1].split('&')[0]}"
        return url
    videos = [to_embed(link) for link in raw_videos]

    # Newsletter subscription
    form = SubscriberForm()
    images = ImageModel.objects.all()
    if request.method == "POST":
        form = SubscriberForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Thank you for subscribing!")
            return redirect("home")

    return render(request, "repair/home.html", {
        "repairs": page_obj,
        "search_query": search_query,
        "videos": videos,
        "form": form,
        "folders": folders,
        "show_modal": show_modal,  # ✅ Pass modal flag to template
        "image" : images
    })


def folder_detail_view(request, folder_slug):
    folder = get_object_or_404(FirmwareFolder, slug=folder_slug)

    firmwares = []  # Used generically in template
    windows_files = []
    windows_iso = []
    if folder_slug == "redmi_eng_firmware":
        firmwares = Firmware.objects.all().order_by('-name')

    elif folder_slug == "windows_app":
        windows_files = WindowsAppFile.objects.all().order_by('-uploaded_at')
    elif folder_slug == "windows_iso":
        windows_iso = WindowsFirmware.objects.all().order_by('-uploaded_at')

    return render(request, f'repair/firmware/{folder_slug}.html', {
        'folder': folder,
        'firmwares': firmwares,
        'windows_files': windows_files,
        'windows_iso': windows_iso,
    })


# def folder_detail_view(request, folder_slug):
#     folder = get_object_or_404(FirmwareFolder, slug=folder_slug)
#     firmwares = folder.firmwares.all()  # ✅ will now work
#     return render(request, f'repair/firmware/{folder.slug}.html', {
#         'folder': folder,
#         'firmwares': firmwares,
#         'files': [],  # optional
#     })


def generate_invoice(request, repair_id):
    repair = get_object_or_404(RepairRequest, id=repair_id)
    # Generate invoice logic here...
    return render(request, 'repair/invoice.html', {'repair': repair})

def export_pdf(request):
    # Filter with safe parameters if needed, or just export all
    repairs = RepairRequest.objects.select_related('customer', 'technician').all()

    template_path = 'repair/pdf_template.html'
    context = {'repairs': repairs}

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="repair_report.pdf"'

    template = get_template(template_path)
    html = template.render(context)

    pisa_status = pisa.CreatePDF(html, dest=response)

    if pisa_status.err:
        return HttpResponse('We had some errors generating the PDF <pre>' + html + '</pre>')
    return response


def export_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="repair_requests.csv"'
    writer = csv.writer(response)
    writer.writerow(['Customer Name', 'Phone', 'Device Model', 'Issue', 'Technician', 'Status', 'Date Received'])

    for r in RepairRequest.objects.select_related('customer', 'technician'):
        writer.writerow([
            r.customer.name,
            r.customer.phone,
            r.device_model,
            r.issue_description,
            r.technician.name if r.technician else 'Not Assigned',
            r.get_status_display(),
            r.date_received.strftime('%Y-%m-%d'),
        ])

    return response

def add_staff(request):
    if request.method == "POST":
        username = request.POST.get("staff_username")
        email = request.POST.get("staff_email")
        password = request.POST.get("staff_password")

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken.")
            return redirect("add_staff")

        User.objects.create(
            username=username,
            email=email,
            password=make_password(password),
            is_staff=True
        )
        messages.success(request, f"✅ Staff '{username}' created successfully.")
        return redirect("profile")
    return redirect("profile")




def add_customer_account(request):
    if request.method == 'POST':
        username = request.POST.get('customer_username')
        email = request.POST.get('customer_email')
        password = request.POST.get('customer_password')
        name = request.POST.get('customer_name')

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")
        else:
            user = User.objects.create_user(username=username, email=email, password=password)
            Customer.objects.create(user=user, name=name)
            messages.success(request, "Customer account created successfully.")
            return redirect('profile')  # or 'profile_info'

    return render(request, 'repair/profile_info.html')





# def add_customer(request):
#     if request.method == "POST":
#         name = request.POST.get("name").strip()
#         phone = request.POST.get("phone").strip()
#         address = request.POST.get("address", "").strip()
#
#         if name and phone:
#             # ✅ Check if customer already exists
#             if Customer.objects.filter(name__iexact=name, phone=phone).exists():
#                 messages.info(request, "Customer already exists.")
#             else:
#                 Customer.objects.create(name=name, phone=phone, address=address)
#                 messages.success(request, "Customer added successfully!")
#         else:
#             messages.error(request, "Please fill in the required fields.")
#
#         return redirect('home')  # Or your dashboard URL
#
#     return redirect(request, "repair/add_customer.html")  # fallback for GET requests


def Add_Repair_request(request):
    if request.method == 'POST':
        customer_name = request.POST.get("customer_name")
        device_model = request.POST.get("device_model")
        issue_description = request.POST.get("issue_description")
        technician_id = request.POST.get("technician")
        status = request.POST.get("status")
        repair_name = request.POST.get("repair_name")
        charge = request.POST.get("charge")
        bonus = request.POST.get("bonus")

        # Create or get existing customer by name
        customer, _ = Customer.objects.get_or_create(name=customer_name)

        # Safely get technician object
        technician = None
        if technician_id:
            try:
                technician = Technician.objects.get(id=technician_id)
            except Technician.DoesNotExist:
                technician = None  # Fallback if ID is invalid

        # Create new repair request
        RepairRequest.objects.create(
            customer=customer,
            device_model=device_model,
            issue_description=issue_description,
            technician=technician,
            status=status,
            repair_name=repair_name,
            charge=charge or 0,
            bonus=bonus or 0
        )

        # Add success message ✅
        messages.success(request, "✅ Repair added successfully!")

        return redirect('home')

    # For GET request, render form
    technicians = Technician.objects.all()
    return render(request, 'repair/add_repair.html', {'technicians': technicians})






def delete_repair(request, repair_id):
    repair = get_object_or_404(RepairRequest, pk=repair_id)
    repair.delete()
    return redirect('home')  #


def edit_repair(request, repair_id):
    repair = get_object_or_404(RepairRequest, id=repair_id)
    customers = Customer.objects.all()
    technicians = Technician.objects.all()

    if request.method == 'POST':
        repair.customer_id = request.POST.get('customer')
        repair.device_model = request.POST.get('device_model')
        repair.issue_description = request.POST.get('issue_description')

        tech_id = request.POST.get('technician')
        repair.technician_id = tech_id if tech_id else None
        repair.status = request.POST.get('status')
        repair.save()
        return redirect('home')

    return render(request, 'repair/edit_repair.html', {
        'repair': repair,
        'customers': customers,
        'technicians': technicians,
    })



def firmware_list(request):
    pass
    # return render(request, 'repair/firmware/redmi_eng_firmware.html', {'firmwares': firmwares}

@csrf_exempt
def grant_access_view(request):
    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        firmware_id = request.POST.get('firmware_id')

        try:
            user = User.objects.get(id=user_id)
            firmware = Firmware.objects.get(id=firmware_id)

            # Create access record (add has_paid=True if the model supports it)
            access_obj, created = FirmwareAccess.objects.get_or_create(
                user=user,
                firmware=firmware,
                defaults={'has_paid': True}  # only if has_paid exists in model
            )

            if not created:
                # Optional: update it if already exists
                access_obj.has_paid = True  # if field exists
                access_obj.save()

            return JsonResponse({'status': 'success', 'message': 'Access granted'})

        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})

    return JsonResponse({'status': 'error', 'message': 'Invalid request method'})


def firmware_info(request, firmware_id):
    firmware = get_object_or_404(Firmware, pk=firmware_id)
    has_access = False

    if request.user.is_authenticated:
        has_access = FirmwareAccess.objects.filter(
            user=request.user,
            firmware=firmware,
            has_paid=True
        ).exists()

    # Get back URL from referer
    back_url = request.META.get('HTTP_REFERER', '/')

    return render(request, 'repair/firmware/model_info.html', {
        'firmware': firmware,
        'has_access': has_access,
        'back_url': back_url,
    })


def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')

    form = AuthenticationForm()
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)

            if not request.POST.get('remember_me'):
                request.session.set_expiry(0)
                messages.info(request, "🔐 Session will expire when browser closes (Remember me unchecked).")
            else:
                request.session.set_expiry(1209600)  # 2 weeks
                messages.info(request, "✅ You will stay logged in (Remember me checked).")

            messages.success(request, f"Welcome back, {user.username}!")
            return redirect('home')
        else:
            messages.error(request, "❌ Invalid username or password.")

    return render(request, 'repair/login_register.html', {'form': form})


def register_view(request):
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        form = CustomRegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.first_name = form.cleaned_data.get('full_name')
            user.email = form.cleaned_data.get('email')
            user.save()
            login(request, user)
            messages.success(request, f"Account created! Welcome, {user.username}")
            return redirect('login_register')
        else:
            print(form.errors.as_data())  # Show exact form errors in terminal
            messages.error(request, "Please correct the errors below.")
    else:
        form = CustomRegisterForm()

    return render(request, 'repair/register.html', {'form': form})



# def login_register_view(request):
#     login_form = AuthenticationForm()
#     register_form = UserCreationForm()
#     form_mode = 'login'  # default tab
#
#     if request.method == 'POST':
#         form_type = request.POST.get('form_type')
#
#         if form_type == 'login':
#             login_form = AuthenticationForm(request, data=request.POST)
#             form_mode = 'login'
#             if login_form.is_valid():
#                 user = login_form.get_user()
#                 login(request, user)
#                 request.session['show_modal'] = True  # ✅ Set only after login
#                 messages.success(request, f"Welcome back, {user.username}!")
#                 return redirect('home')
#             else:
#                 messages.error(request, "Invalid login credentials.")
#
#         elif form_type == 'register':
#             register_form = UserCreationForm(request.POST)
#             form_mode = 'register'
#             if register_form.is_valid():
#                 user = register_form.save()
#                 login(request, user)
#                 request.session['show_modal'] = True  # ✅ Set only after register
#                 messages.success(request, f"Registration successful. Welcome, {user.username}!")
#                 return redirect('home')
#             else:
#                 messages.error(request, "Please correct the errors below.")
#
#     return render(request, 'repair/login_register.html', {
#         'login_form': login_form,
#         'register_form': register_form,
#         'form_mode': form_mode,
#     })


def logout_view(request):
    logout(request)
    return redirect('login_register')  # or wherever your login page is




@login_required
def technician_dashboard(request):
    accesses = FirmwareAccess.objects.filter(user=request.user).select_related('firmware')
    technicians = Technician.objects.all()
    return render(request, 'repair/technician_dashboard.html', {
        'accesses': accesses,
        'technicians': technicians
    })

# def technician_dashboard(request):
#     context = {
#         'technicians': Technician.objects.all()
#     }
#     return render(request, 'repair/technician_dashboard.html', context)


def add_technician(request):
    if request.method == 'POST':
        name = request.POST.get('technician_name', '').strip()
        phone = request.POST.get('technician_phone', '').strip()
        tech_type = request.POST.get('type', '').strip()

        if name and phone:
            # ✅ Check if technician with same name and phone already exists
            if Technician.objects.filter(name__iexact=name, phone=phone).exists():
                messages.info(request, "Technician already exists.")
            else:
                Technician.objects.create(name=name, phone=phone, type=tech_type)
                messages.success(request, "Technician added successfully.")
        else:
            messages.error(request, "Both name and phone are required.")

    return redirect('profile')


# views.py
def subscribe_view(request):
    if request.method == "POST":
        form = SubscriberForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')  # or any success page
    else:
        form = SubscriberForm()

    return render(request, 'repair/subscribe.html', {'form': form})

# thext ssend emaill
# def add_technician(request):
#     send_mail(
#         'Test Email',
#         'This is a test email from Django.',
#         'repairmymobileimphal@gmail.com',
#         ['malemakcom@gmail.com'],
#         fail_silently=False,
#     )
#     return HttpResponse("Email sent")




class MyPasswordResetView(auth_views.PasswordResetView):
    template_name = 'repair/password_reset_form.html'
    email_template_name = 'repair/password_reset_email.html'
    success_url = reverse_lazy('password_reset_done')

class MyPasswordResetDoneView(auth_views.PasswordResetDoneView):
    template_name = 'repair/password_reset_done.html'

class MyPasswordResetConfirmView(auth_views.PasswordResetConfirmView):
    template_name = 'repair/password_reset_confirm.html'
    success_url = reverse_lazy('password_reset_complete')

class MyPasswordResetCompleteView(auth_views.PasswordResetCompleteView):
    template_name = 'repair/password_reset_complete.html'



from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.shortcuts import render, redirect
from .models import SamsungModel, DeviceModel, FirmwareAccess, Technician
from .forms import BulkSamsungUploadForm
from django.contrib.auth.models import User

@login_required
def profile_view(request):
    device_models_qs = DeviceModel.objects.all().order_by('brand', 'model_name')
    paginator = Paginator(device_models_qs, 15)
    page_number_ = request.GET.get("page")
    page_obj_model = paginator.get_page(page_number_)

    # Handle Bulk Upload form
    bulk_form = BulkSamsungUploadForm()
    if request.method == 'POST' and 'bulk_data' in request.POST:
        bulk_form = BulkSamsungUploadForm(request.POST)
        if bulk_form.is_valid():
            lines = bulk_form.cleaned_data['bulk_data'].strip().splitlines()
            objects = []
            for line in lines:
                parts = line.split('\t')
                if len(parts) >= 3:
                    name = parts[0].strip()
                    number = parts[1].strip()
                    support = parts[2].strip().lower() in ['yes', 'true', '1']
                    objects.append(SamsungModel(model_name=name, model_number=number, is_supported=support))
            SamsungModel.objects.bulk_create(objects)
            return redirect('profile')  # Redirect back to same view

    context = {
        'page_obj': page_obj_model,
        'accesses': FirmwareAccess.objects.filter(user=request.user),
        'technicians': Technician.objects.all(),
        'device_models': device_models_qs,
        'bulk_form': bulk_form,
    }

    if request.user.is_superuser:
        context['admins'] = User.objects.filter(is_superuser=True)
        context['staffs'] = User.objects.filter(is_staff=True, is_superuser=False)
        context['customers'] = User.objects.filter(is_staff=False, is_superuser=False)
    elif request.user.is_staff:
        context['customers'] = User.objects.filter(is_staff=False, is_superuser=False)

    return render(request, 'repair/profile_info.html', context)

@login_required
def samsung_frp_support_list(request):
    samsung_models = SamsungModel.objects.all().order_by('model_name', 'model_number')
    return render(request, 'repair/samsung_frp_support_list.html', {
        'samsung_models': samsung_models
    })

@login_required
def edit_profile(request):
    return render(request, 'repair/edit_profile.html')  # Create this template later



@login_required
def account(request):
    admins = User.objects.filter(is_superuser=True)
    staffs = User.objects.filter(is_staff=True, is_superuser=False)
    customers = User.objects.filter(is_staff=False, is_superuser=False)

    return render(request, 'repair/technician_dashboard.html', {
        'admins': admins,
        'staffs': staffs,
        'customers': customers,
    })


@login_required
def check_page(request):
    return render(request, 'repair/check_page.html', {
        'user': request.user,
        'ip': request.META.get('REMOTE_ADDR'),
        'agent': request.META.get('HTTP_USER_AGENT'),
    })

def device_model_suggestions(request):
    query = request.GET.get("term", "")
    results = DeviceModel.objects.filter(model_name__icontains=query)[:10]
    suggestions = [f"{d.brand} {d.model_name}" for d in results]
    return JsonResponse(suggestions, safe=False)

def add_phone_model(request):
    if request.method == 'POST':
        brand = request.POST.get('brand', '').strip()
        model_name = request.POST.get('model_name', '').strip()

        if brand and model_name:
            # Check if already exists
            if DeviceModel.objects.filter(brand__iexact=brand, model_name__iexact=model_name).exists():
                messages.warning(request, f"The model '{brand} {model_name}' already exists.")
            else:
                try:
                    DeviceModel.objects.create(brand=brand, model_name=model_name)
                    messages.success(request, "Phone model added successfully.")
                except IntegrityError:
                    messages.error(request, f"Could not add '{brand} {model_name}' — already exists.")
        else:
            messages.error(request, "Both brand and model name are required.")

    return redirect('profile_info')


def get_device_models(request):
    term = request.GET.get('term', '').strip()

    # Search both brand and model_name
    models = DeviceModel.objects.filter(
        Q(model_name__icontains=term) | Q(brand__icontains=term)
    ).distinct()[:10]

    suggestions = [f"{m.brand} {m.model_name}" for m in models]
    return JsonResponse(suggestions, safe=False)




@login_required
def delete_phone_model(request, model_id):
    if request.method == 'POST':
        try:
            DeviceModel.objects.get(id=model_id).delete()
            messages.success(request, "Model deleted.")
        except DeviceModel.DoesNotExist:
            messages.error(request, "Model not found.")
    return redirect('profile')


# def samsung_read_info(request):
#     if request.method == "POST":
#         model = request.POST.get("model")
#         imei = request.POST.get("imei")
#
#         # Process the data here...
#         messages.success(request, f"Model: {model}, IMEI: {imei} submitted successfully.")
#
#         return redirect("samsung_tools")  # Replace with your page URL name
#     return render(request, "repair/samsung_tools.html")

def samsung_tools(request):
    return render(request, 'repair/samsung_tools.html')

def samsung_read_info(request):
    if request.method == "POST":
        model = request.POST.get("model")
        imei = request.POST.get("imei")

        # Optional: validate/store info
        if len(imei) < 14:
            messages.error(request, "Invalid IMEI. Must be at least 14 digits.")
        else:
            messages.success(request, f"Model: {model}, IMEI: {imei} submitted!")

        return redirect("samsung_tools")
    return redirect("samsung_tools")


# def bulk_upload(request):
#     if request.method == 'POST':
#         form = BulkSamsungUploadForm(request.POST)
#         if form.is_valid():
#             lines = form.cleaned_data['bulk_data'].strip().splitlines()
#             objects = []
#             for line in lines:
#                 parts = line.split('\t')
#                 if len(parts) >= 3:
#                     name = parts[0].strip()
#                     number = parts[1].strip()
#                     support = parts[2].strip().lower() in ['yes', 'true', '1']
#                     objects.append(SamsungModel(model_name=name, model_number=number, is_supported=support))
#             SamsungModel.objects.bulk_create(objects)
#             return redirect('your_success_page_or_list')
#     else:
#         form = BulkSamsungUploadForm()
#
#     return render(request, 'bulk_upload.html', {'form': form})