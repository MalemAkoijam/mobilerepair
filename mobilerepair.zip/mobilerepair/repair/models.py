# Create your models here.
import math

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.db import models
from django.utils import timezone
from django.utils.text import slugify
from django import forms



class SamsungModel(models.Model):
    model_name = models.CharField(max_length=100)
    model_number = models.CharField(max_length=255)
    is_supported = models.BooleanField(default=False)

    def __str__(self):
        return self.model_name

class CustomRegisterForm(UserCreationForm):
    full_name = forms.CharField(max_length=150, required=True)
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ['username', 'full_name', 'email', 'password1', 'password2']

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    login_ip = models.GenericIPAddressField(null=True, blank=True)
    agent = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.user.username


class ImageModel(models.Model):
    title = models.CharField(max_length=100, blank=True)
    image = models.ImageField(upload_to='uploads/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title or f"Image {self.id}"

# models.py
class Customer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.user.username} ({self.name})"


# models.py
class Technician(models.Model):
    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)
    type = models.CharField(max_length=20, choices=[('Software', 'Software'), ('Hardware', 'Hardware')])

    def __str__(self):
        return f"{self.name} ({self.type})"



class RepairRequest(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
    ]

    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    device_model = models.CharField(max_length=100)
    issue_description = models.TextField()
    date_received = models.DateField(auto_now_add=True)
    technician = models.ForeignKey(Technician, on_delete=models.SET_NULL, null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    remarks = models.TextField(blank=True, null=True)
    repair_name = models.CharField(max_length=255, blank=True, null=True)
    charge = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    bonus = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)


    def __str__(self):
        return f"{self.device_model} - {self.customer.name}"



# models.py
class Subscriber(models.Model):
    email = models.EmailField(unique=True)
    subscribed_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.email




class Firmware(models.Model):
    folder = models.ForeignKey('FirmwareFolder', on_delete=models.CASCADE, related_name='firmwares')  # ✅ Add this line
    name = models.CharField(max_length=100)
    image = models.URLField()
    format_type = models.CharField(max_length=50)
    description = models.TextField()
    android_version = models.CharField(max_length=20)
    size = models.CharField(max_length=20)
    file_url = models.URLField()
    date = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.name

    def image_url(self):
        if self.image and hasattr(self.image, 'url'):
            return self.image.url
        return ''




class FirmwareAccess(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    firmware = models.ForeignKey(Firmware, on_delete=models.CASCADE)
    has_paid = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'firmware')  # Ensure one access per user per firmware

    def __str__(self):
        return f"{self.user.username} - {self.firmware.name}"


class DeviceModel(models.Model):
    brand = models.CharField(max_length=100)
    model_name = models.CharField(max_length=100)

    class Meta:
        unique_together = ('brand', 'model_name')

    def __str__(self):
        return f"{self.brand} {self.model_name}"


class FirmwareFolder(models.Model):
    name = models.CharField(max_length=255)
    slug = models.SlugField(unique=True, blank=True)  # ✅ Make sure this is included!

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.name)
            slug = base_slug
            counter = 1
            while FirmwareFolder.objects.exclude(pk=self.pk).filter(slug=slug).exists():
                slug = f"{base_slug}-{counter}"
                counter += 1
            self.slug = slug
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name




# in models.py

class FileMixin:
    def formatted_size(self):
        if self.file_size == 0:
            return "0 Bytes"
        size_name = ("Bytes", "KB", "MB", "GB", "TB")
        i = int(math.floor(math.log(self.file_size, 1024)))
        p = math.pow(1024, i)
        s = round(self.file_size / p, 2)
        return f"{s} {size_name[i]}"


### WIndow Firmware
class WindowsFirmware(models.Model, FileMixin):
    file_name = models.CharField(max_length=255)
    cloud_url = models.URLField()
    file_size = models.BigIntegerField()
    uploaded_at = models.DateTimeField(auto_now_add=True)


    def __str__(self):
        return self.file_name

### window file
class WindowsAppFile(models.Model):
    file_name = models.CharField(max_length=255)
    cloud_url = models.URLField()
    file_size = models.BigIntegerField()
    uploaded_at = models.DateTimeField(auto_now_add=True)


    def __str__(self):
        return self.file_name


