from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import (Customer, Technician, RepairRequest, Firmware, FirmwareAccess,
                     FirmwareFolder, DeviceModel, Profile, \
                     WindowsAppFile, WindowsFirmware, ImageModel)
from .models import Subscriber

admin.site.register(ImageModel)
admin.site.register(Profile)
admin.site.register(Customer)
admin.site.register(Technician)
admin.site.register(RepairRequest)

admin.site.register(Subscriber)
admin.site.register(Firmware)
admin.site.register(FirmwareAccess)
admin.site.register(DeviceModel)
admin.site.register(FirmwareFolder)
admin.site.register(WindowsAppFile)
admin.site.register(WindowsFirmware)

